# maixcam_vision_multi_target.py
# MaixCam Pro vision module.
# Mode 0: idle, fill light off.
# Mode 1: detect red/green/blue materials.
# Mode 2: detect red/green/blue rings.

from maix import camera, display, image, uart, pinmap, app, time, err, nn, gpio
import gc


# =========================
# UART0 config
# =========================
UART_DEVICE = "/dev/ttyS0"
UART_BAUDRATE = 9600
UART_PINS = {"A16": "UART0_TX", "A17": "UART0_RX"}

for pin, func in UART_PINS.items():
    err.check_raise(pinmap.set_pin_function(pin, func), "Failed set pin {} to {}".format(pin, func))

serial = uart.UART(UART_DEVICE, UART_BAUDRATE)
print("UART open: {}, baudrate {}".format(UART_DEVICE, UART_BAUDRATE))


# =========================
# Fill light
# =========================
fill_light = None
try:
    err.check_raise(pinmap.set_pin_function("B3", "GPIOB3"), "Failed set fill light pin")
    fill_light = gpio.GPIO("GPIOB3", gpio.Mode.OUT)
    fill_light.value(0)
    print("Fill light LED off")
except Exception as e:
    print("Fill light LED init failed: {}".format(e))


# =========================
# Camera and display config
# =========================
IMG_W = 640
IMG_H = 480
CAM_FPS = 30
CAM_BUFF_NUM = 1
SHOW_IMAGE = True
DISPLAY_EVERY_N = 3
PRINT_FPS = True
GC_EVERY_N = 80

REPORT_INTERVAL_MS = 60
SERIAL_COORD_MAX = 240


def scale_roi(x, y, w, h):
    sx = IMG_W / 640.0
    sy = IMG_H / 480.0
    return [int(x * sx), int(y * sy), int(w * sx), int(h * sy)]


ROI_MATERIAL = scale_roi(0, 0, 640, 480)
ROI_RING = scale_roi(0, 0, 640, 480)

MODE_IDLE = 0
MODE_MATERIAL = 1
MODE_RING = 2
MODE_NAMES = {
    MODE_IDLE: "Idle",
    MODE_MATERIAL: "Material",
    MODE_RING: "Ring",
}

TARGET_NAMES = ["RED", "GREEN", "BLUE"]
TARGET_COLORS = [image.COLOR_RED, image.COLOR_GREEN, image.COLOR_BLUE]

FRAME_HEADER = 0x55
FRAME_MULTI_TARGET = 0x5B
FRAME_TAIL = 0xAA


# =========================
# Camera init
# =========================
cam = camera.Camera(IMG_W, IMG_H, fps=CAM_FPS, buff_num=CAM_BUFF_NUM)
cam.skip_frames(20)

try:
    cam.awb_mode(camera.AwbMode.Manual)
    cam.set_wb_gain([0.134, 0.0625, 0.0625, 0.1239])
except Exception:
    pass

try:
    cam.saturation(60)
except Exception:
    pass

if SHOW_IMAGE:
    disp = display.Display()
else:
    disp = None


# =========================
# YOLOv5 models
# =========================
ring_detector = None
try:
    ring_detector = nn.YOLOv5(model="/root/models/maixhub/test_ring/test_ring.mud")
    print("Ring model loaded: {}x{}".format(ring_detector.input_width(), ring_detector.input_height()))
except Exception as e:
    print("Ring model load failed: {}".format(e))

material_detector = None
try:
    material_detector = nn.YOLOv5(model="/root/models/maixhub/test_material/test_material.mud")
    print("Material model loaded: {}x{}".format(material_detector.input_width(), material_detector.input_height()))
except Exception as e:
    print("Material model load failed: {}".format(e))


# =========================
# UART protocol
# =========================
def clamp_byte(value):
    return max(0, min(255, int(value)))


def scale_coord(x, y):
    sx = clamp_byte(x * SERIAL_COORD_MAX / IMG_W)
    sy = clamp_byte(y * SERIAL_COORD_MAX / IMG_H)
    return sx, sy


def read_mode_command(current_mode):
    data = serial.read()
    if not data:
        return current_mode

    if isinstance(data, int):
        data = [data]

    new_mode = current_mode
    for b in data:
        if 0x30 <= b <= 0x32:
            new_mode = b - 0x30
    return new_mode


def send_multi_targets(mode, targets):
    payload = [FRAME_HEADER, FRAME_MULTI_TARGET, mode, len(targets)]
    for target in targets:
        payload.extend([target["cls"], target["sx"], target["sy"]])
    payload.append(FRAME_TAIL)
    serial.write(bytes(payload))


def set_fill_light(mode):
    if fill_light is None:
        return
    fill_light.value(1 if mode in (MODE_MATERIAL, MODE_RING) else 0)


# =========================
# Detection and drawing
# =========================
def detect_three_targets(img, model, roi):
    if model is None:
        return []

    model_w = model.input_width()
    model_h = model.input_height()
    img_small = img.resize(model_w, model_h)
    objs = model.detect(img_small, conf_th=0.5, iou_th=0.45)

    scale_x = IMG_W / model_w
    scale_y = IMG_H / model_h
    best_by_cls = {}

    for obj in objs:
        cls = int(obj.class_id) + 1
        if cls < 1 or cls > 3:
            continue

        box_x = obj.x * scale_x
        box_y = obj.y * scale_y
        box_w = obj.w * scale_x
        box_h = obj.h * scale_y
        cx = box_x + box_w / 2.0
        cy = box_y + box_h / 2.0

        if cx < roi[0] or cx > roi[0] + roi[2] or cy < roi[1] or cy > roi[1] + roi[3]:
            continue

        area = box_w * box_h
        score = obj.score
        old = best_by_cls.get(cls)
        if old is not None and score <= old["score"] and area <= old["area"]:
            continue

        sx, sy = scale_coord(cx, cy)
        best_by_cls[cls] = {
            "cls": cls,
            "x": int(box_x),
            "y": int(box_y),
            "w": int(box_w),
            "h": int(box_h),
            "cx": int(cx),
            "cy": int(cy),
            "sx": sx,
            "sy": sy,
            "score": score,
            "area": area,
        }

    return [best_by_cls[cls] for cls in sorted(best_by_cls.keys())]


def draw_targets(img, targets, title):
    img.draw_string(2, 2, title, image.COLOR_WHITE)

    for target in targets:
        idx = target["cls"] - 1
        color = TARGET_COLORS[idx]
        name = TARGET_NAMES[idx]
        x = target["x"]
        y = target["y"]
        w = target["w"]
        h = target["h"]
        cx = target["cx"]
        cy = target["cy"]

        img.draw_rect(x, y, w, h, color, 3)
        img.draw_line(cx - 8, cy, cx + 8, cy, color, 2)
        img.draw_line(cx, cy - 8, cx, cy + 8, color, 2)
        img.draw_string(x, max(0, y - 18), "{} ({},{})".format(name, target["sx"], target["sy"]), color)


def show_idle(img):
    img.draw_string(2, 2, "Mode0:Idle", image.COLOR_GREEN)
    if disp is not None:
        disp.show(img)


def show_targets(img, roi, targets, mode_name):
    img.draw_rect(roi[0], roi[1], roi[2], roi[3], image.COLOR_BLUE, 2)
    draw_targets(img, targets, mode_name)
    if not targets:
        img.draw_string(2, 22, "No Target", image.COLOR_RED)
    if disp is not None:
        disp.show(img)


# =========================
# Main loop
# =========================
mode_command = MODE_RING
last_mode = None
frame_id = 0
fps_count = 0
fps_t0 = time.ticks_ms()
last_report_ms = 0

while not app.need_exit():
    frame_id += 1
    fps_count += 1
    now = time.ticks_ms()

    mode_command = read_mode_command(mode_command)
    if mode_command != last_mode:
        set_fill_light(mode_command)
        last_mode = mode_command
        print("Mode changed to {}".format(mode_command))

    img = cam.read()

    if mode_command == MODE_IDLE:
        if SHOW_IMAGE and frame_id % DISPLAY_EVERY_N == 0:
            show_idle(img)
        time.sleep_ms(1)
        continue

    if mode_command == MODE_MATERIAL:
        model = material_detector
        roi = ROI_MATERIAL
    elif mode_command == MODE_RING:
        model = ring_detector
        roi = ROI_RING
    else:
        mode_command = MODE_IDLE
        time.sleep_ms(1)
        continue

    targets = detect_three_targets(img, model, roi)

    if now - last_report_ms >= REPORT_INTERVAL_MS:
        send_multi_targets(mode_command, targets)
        last_report_ms = now

    if SHOW_IMAGE and frame_id % DISPLAY_EVERY_N == 0:
        title = "Mode{}:{}".format(mode_command, MODE_NAMES.get(mode_command, "Unknown"))
        show_targets(img, roi, targets, title)

    if PRINT_FPS and now - fps_t0 >= 1000:
        print("fps:", fps_count, "cmd:", mode_command, "targets:", len(targets))
        fps_count = 0
        fps_t0 = now

    if frame_id % GC_EVERY_N == 0:
        gc.collect()

    time.sleep_ms(1)
